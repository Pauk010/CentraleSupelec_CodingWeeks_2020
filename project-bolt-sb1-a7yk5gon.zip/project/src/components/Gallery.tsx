import React, { useState } from 'react';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';

const images = [
  {
    url: "https://images.unsplash.com/photo-1632759145351-1d592919f522",
    title: "Traditionelles Schieferdach"
  },
  {
    url: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c",
    title: "Moderne Dachkonstruktion"
  },
  {
    url: "https://images.unsplash.com/photo-1600573472591-ee6c563aabc0",
    title: "Handwerkliche Präzision"
  },
  {
    url: "https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde",
    title: "Klassisches Ziegeldach"
  },
  {
    url: "https://images.unsplash.com/photo-1600047509697-5191d6eec0d2",
    title: "Flachdach-Installation"
  },
  {
    url: "https://images.unsplash.com/photo-1600047509358-9dc75507daeb",
    title: "Dachsanierung"
  },
  {
    url: "https://images.unsplash.com/photo-1600047508788-786f3865b4b9",
    title: "Dachrinnen-Montage"
  },
  {
    url: "https://images.unsplash.com/photo-1600047508967-f9cd41e08ac4",
    title: "Dachfenster-Einbau"
  },
  {
    url: "https://images.unsplash.com/photo-1600585154526-990dced4db0d",
    title: "Metalldach-Installation"
  },
  {
    url: "https://images.unsplash.com/photo-1600573472591-ee6c563aabc0",
    title: "Dachstuhl-Reparatur"
  },
  {
    url: "https://images.unsplash.com/photo-1600047509358-9dc75507daeb",
    title: "Wärmedämmung"
  },
  {
    url: "https://images.unsplash.com/photo-1600047508788-786f3865b4b9",
    title: "Garagendach"
  },
  {
    url: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c",
    title: "Dachbleche"
  },
  {
    url: "https://images.unsplash.com/photo-1632759145351-1d592919f522",
    title: "Schneefangsysteme"
  },
  {
    url: "https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde",
    title: "Dacheindeckung"
  },
  {
    url: "https://images.unsplash.com/photo-1600047509697-5191d6eec0d2",
    title: "Isolierung"
  }
];

export default function Gallery() {
  const [selectedImage, setSelectedImage] = useState<number | null>(null);

  const nextImage = () => {
    if (selectedImage === null) return;
    setSelectedImage((selectedImage + 1) % images.length);
  };

  const previousImage = () => {
    if (selectedImage === null) return;
    setSelectedImage((selectedImage - 1 + images.length) % images.length);
  };

  const handleKeyDown = (e: KeyboardEvent) => {
    if (selectedImage === null) return;
    if (e.key === 'ArrowRight') nextImage();
    if (e.key === 'ArrowLeft') previousImage();
    if (e.key === 'Escape') setSelectedImage(null);
  };

  React.useEffect(() => {
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [selectedImage]);

  return (
    <section id="gallery" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Unsere Galerie</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {images.map((image, index) => (
            <div
              key={index}
              className="group relative bg-white rounded-lg shadow-lg overflow-hidden cursor-pointer transform transition-all duration-300 hover:scale-105"
              onClick={() => setSelectedImage(index)}
            >
              <div className="relative aspect-[4/3]">
                <img
                  src={`${image.url}?auto=format&fit=crop&w=600&q=80`}
                  alt={image.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
                    <h3 className="font-semibold text-lg transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                      {image.title}
                    </h3>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Lightbox */}
        {selectedImage !== null && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-90 p-4">
            <button
              className="absolute top-4 right-4 text-white hover:text-gray-300 transition-colors"
              onClick={() => setSelectedImage(null)}
            >
              <X className="w-8 h-8" />
            </button>

            <button
              className="absolute left-4 top-1/2 -translate-y-1/2 text-white hover:text-gray-300 transition-colors"
              onClick={previousImage}
            >
              <ChevronLeft className="w-8 h-8" />
            </button>

            <button
              className="absolute right-4 top-1/2 -translate-y-1/2 text-white hover:text-gray-300 transition-colors"
              onClick={nextImage}
            >
              <ChevronRight className="w-8 h-8" />
            </button>

            <div className="relative max-h-[90vh] max-w-[90vw]">
              <img
                src={`${images[selectedImage].url}?auto=format&fit=crop&w=1200&q=80`}
                alt={images[selectedImage].title}
                className="max-h-[90vh] max-w-[90vw] object-contain"
              />
              <div className="absolute bottom-0 left-0 right-0 p-4 text-center bg-gradient-to-t from-black/50 to-transparent">
                <h3 className="text-white text-xl font-semibold mb-2">
                  {images[selectedImage].title}
                </h3>
                <p className="text-gray-300 text-sm">
                  {selectedImage + 1} von {images.length}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}