import React, { useState } from 'react';
import { ChevronDown, Phone, Mail, MessageCircle, Home, PenTool as Tools, Warehouse, Droplets, Square, Layers } from 'lucide-react';

const services = [
  {
    icon: <Home className="w-6 h-6" />,
    title: 'Dachdecker',
    description: 'Professionelle Dachdeckerarbeiten für Neu- und Altbauten',
    details: [
      'Komplette Dacheindeckungen',
      'Dachsanierung und Renovierung',
      'Wärmedämmung nach aktuellen Standards',
      'Dachfenstereinbau und -austausch',
      'Reparatur von Sturmschäden'
    ],
    benefits: [
      'Langlebige Qualitätsarbeit',
      'Termingerechte Ausführung',
      'Professionelle Beratung',
      'Kostenlose Angebotserstellung'
    ]
  },
  {
    icon: <Tools className="w-6 h-6" />,
    title: 'Handwerker',
    description: 'Vielseitige Handwerksleistungen rund ums Dach',
    details: [
      'Holzarbeiten und Zimmermannsarbeiten',
      'Installation von Schneefangsystemen',
      'Montage von Dachrinnen',
      'Reparatur von Dachstühlen',
      'Wartungsarbeiten und Inspektionen'
    ],
    benefits: [
      'Erfahrene Fachkräfte',
      'Hochwertige Materialien',
      'Saubere Arbeitsweise',
      'Umfassender Service'
    ]
  },
  {
    icon: <Warehouse className="w-6 h-6" />,
    title: 'Dach Garage eindecken',
    description: 'Fachgerechte Eindeckung von Garagendächern',
    details: [
      'Planung und Beratung',
      'Wasserdichte Abdichtung',
      'Isolierung und Dämmung',
      'Integration von Belüftungssystemen',
      'Anpassung an bestehende Gebäude'
    ],
    benefits: [
      'Maßgeschneiderte Lösungen',
      'Witterungsbeständige Ausführung',
      'Optimale Entwässerung',
      'Lange Haltbarkeit'
    ]
  },
  {
    icon: <Droplets className="w-6 h-6" />,
    title: 'Dachrinne',
    description: 'Installation und Wartung von Dachrinnen-Systemen',
    details: [
      'Montage neuer Dachrinnen',
      'Reparatur beschädigter Rinnen',
      'Reinigung und Wartung',
      'Installation von Fallrohren',
      'Optimierung der Wasserableitung'
    ],
    benefits: [
      'Effektiver Gebäudeschutz',
      'Professionelle Montage',
      'Regelmäßige Wartung',
      'Langlebige Systeme'
    ]
  },
  {
    icon: <Square className="w-6 h-6" />,
    title: 'Flachdach',
    description: 'Spezialist für Flachdachkonstruktionen und -sanierung',
    details: [
      'Neuinstallation von Flachdächern',
      'Abdichtung und Isolierung',
      'Dachbegrünung und Terrassenaufbau',
      'Sanierung undichter Stellen',
      'Wartung und Pflege'
    ],
    benefits: [
      'Maximale Raumnutzung',
      'Hohe Energieeffizienz',
      'Moderne Materialien',
      'Nachhaltige Lösungen'
    ]
  },
  {
    icon: <Layers className="w-6 h-6" />,
    title: 'Dachbleche Montage',
    description: 'Professionelle Montage von Dachblechen',
    details: [
      'Installation von Metalldächern',
      'Verarbeitung verschiedener Materialien',
      'Anpassung an komplexe Dachformen',
      'Korrosionsschutz und Beschichtung',
      'Reparatur von Beschädigungen'
    ],
    benefits: [
      'Schnelle Installation',
      'Hohe Wetterbeständigkeit',
      'Geringes Gewicht',
      'Lange Lebensdauer'
    ]
  }
];

export default function Services() {
  const [openService, setOpenService] = useState<number | null>(null);
  const phoneNumber = "015750919983";
  const whatsappLink = `https://wa.me/49${phoneNumber.replace(/^0/, '')}`;

  const toggleService = (index: number) => {
    setOpenService(openService === index ? null : index);
  };

  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Unsere Leistungen</h2>
          <p className="text-xl text-gray-600">
            Professionelle Dachlösungen für jeden Bedarf
          </p>
        </div>

        <div className="max-w-3xl mx-auto space-y-4">
          {services.map((service, index) => (
            <div key={index} className="overflow-hidden">
              <button
                onClick={() => toggleService(index)}
                className={`w-full p-6 text-left transition-colors duration-300 flex justify-between items-center ${
                  openService === index 
                    ? 'bg-orange-400 text-white'
                    : 'bg-orange-400 text-white hover:bg-orange-500'
                } rounded-lg`}
              >
                <div className="flex items-center gap-3">
                  {service.icon}
                  <span className="text-xl font-semibold">{service.title}</span>
                </div>
                <ChevronDown 
                  className={`w-6 h-6 transition-transform duration-300 ${
                    openService === index ? 'rotate-180' : ''
                  }`}
                />
              </button>

              <div
                className={`transition-all duration-300 ease-in-out bg-white rounded-b-lg shadow-lg ${
                  openService === index
                    ? 'max-h-[1000px] opacity-100 transform translate-y-0'
                    : 'max-h-0 opacity-0 transform -translate-y-4'
                }`}
              >
                <div className="p-6">
                  <p className="text-lg text-gray-600 mb-6">{service.description}</p>

                  <div className="grid md:grid-cols-2 gap-8">
                    <div>
                      <h4 className="text-xl font-semibold text-gray-800 mb-4">Leistungen</h4>
                      <ul className="space-y-3">
                        {service.details.map((detail, idx) => (
                          <li 
                            key={idx}
                            className="flex items-start"
                          >
                            <span className="text-orange-500 mr-2">•</span>
                            <span className="text-gray-600">{detail}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h4 className="text-xl font-semibold text-gray-800 mb-4">Ihre Vorteile</h4>
                      <ul className="space-y-3">
                        {service.benefits.map((benefit, idx) => (
                          <li 
                            key={idx}
                            className="flex items-start"
                          >
                            <span className="text-orange-500 mr-2">•</span>
                            <span className="text-gray-600">{benefit}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-4">
                      <a
                        href={`tel:${phoneNumber}`}
                        className="flex items-center justify-center gap-2 bg-orange-500 text-white px-6 py-3 rounded-lg hover:bg-orange-600 transition-colors w-full"
                      >
                        <Phone className="w-5 h-5" />
                        <span>Jetzt anrufen</span>
                      </a>
                      <a
                        href={whatsappLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-center gap-2 bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors w-full"
                      >
                        <MessageCircle className="w-5 h-5" />
                        <span>WhatsApp Chat</span>
                      </a>
                    </div>
                    <div className="space-y-4">
                      <a
                        href="mailto:tonigabor24@yahoo.com"
                        className="flex items-center justify-center gap-2 bg-gray-600 text-white px-6 py-3 rounded-lg hover:bg-gray-700 transition-colors w-full"
                      >
                        <Mail className="w-5 h-5" />
                        <span>E-Mail senden</span>
                      </a>
                      <a
                        href="#contact"
                        className="flex items-center justify-center gap-2 border-2 border-orange-500 text-orange-500 px-6 py-3 rounded-lg hover:bg-orange-50 transition-colors w-full"
                      >
                        Kontaktformular
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <p className="text-gray-600 mb-8">
            Kontaktieren Sie uns für ein kostenloses Angebot oder eine Beratung zu unseren Leistungen.
          </p>
          <a
            href="#contact"
            className="inline-block bg-orange-500 text-white px-8 py-3 rounded-lg hover:bg-orange-600 transition-colors"
          >
            Kostenloses Angebot
          </a>
        </div>
      </div>
    </section>
  );
}