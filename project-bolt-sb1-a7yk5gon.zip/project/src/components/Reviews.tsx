import React from 'react';
import { Star, Quote } from 'lucide-react';

const reviews = [
  {
    name: "Michael Schmidt",
    location: "Köln-Porz",
    rating: 5,
    text: "Hervorragende Arbeit bei der Dachsanierung! Das Team von Toni Roofer Construct war äußerst professionell und hat alle Arbeiten termingerecht abgeschlossen.",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80"
  },
  {
    name: "Anna Weber",
    location: "Köln-Mülheim",
    rating: 4,
    text: "Sehr kompetente Beratung und gute Ausführung der Dachrinneninstallation. Faire Preise und zuverlässig. Kleine Verzögerungen im Zeitplan, aber insgesamt zufrieden.",
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=150&q=80"
  },
  {
    name: "Thomas Becker",
    location: "Köln-Deutz",
    rating: 5,
    text: "Die Qualität der Arbeit ist beeindruckend. Besonders die Detailgenauigkeit und Sauberkeit während der gesamten Dachdeckerarbeiten hat uns überzeugt.",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&q=80"
  },
  {
    name: "Lisa Müller",
    location: "Köln-Kalk",
    rating: 4,
    text: "Toni und sein Team haben unsere Garage mit einem neuen Dach versehen. Gute Arbeit zu einem fairen Preis. Die Kommunikation hätte etwas besser sein können.",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80"
  },
  {
    name: "Klaus Wagner",
    location: "Köln-Holweide",
    rating: 5,
    text: "Professionelle Flachdachsanierung mit bester Beratung. Das Team ist sehr freundlich und arbeitet präzise. Wir sind rundum zufrieden.",
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80"
  },
  {
    name: "Maria Koch",
    location: "Köln-Dellbrück",
    rating: 4,
    text: "Gute handwerkliche Leistung bei der Installation unseres neuen Dachs. Termintreu und zuverlässig. Ein paar kleine Nachbesserungen waren nötig.",
    image: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?auto=format&fit=crop&w=150&q=80"
  }
];

export default function Reviews() {
  return (
    <section id="reviews" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Kundenbewertungen</h2>
          <p className="text-xl text-gray-600">
            Was unsere Kunden über uns sagen
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {reviews.map((review, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-lg relative">
              <Quote className="absolute top-4 right-4 w-8 h-8 text-blue-100" />
              
              <div className="flex items-center mb-4">
                <img
                  src={review.image}
                  alt={review.name}
                  className="w-16 h-16 rounded-full object-cover mr-4"
                />
                <div>
                  <h3 className="font-semibold text-gray-800">{review.name}</h3>
                  <p className="text-gray-600 text-sm">{review.location}</p>
                </div>
              </div>

              <div className="flex mb-4">
                {[...Array(review.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                ))}
                {[...Array(5 - review.rating)].map((_, i) => (
                  <Star key={i + review.rating} className="w-5 h-5 text-gray-200" />
                ))}
              </div>

              <p className="text-gray-600">{review.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}