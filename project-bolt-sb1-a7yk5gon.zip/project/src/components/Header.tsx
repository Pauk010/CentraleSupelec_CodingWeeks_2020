import React from 'react';
import { Menu, Phone, Mail, X } from 'lucide-react';
import { useState } from 'react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-md fixed w-full z-50">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-20">
          <div className="flex items-center">
            <div className="h-16 w-auto mr-3">
              <svg viewBox="0 0 400 400" className="h-full w-auto">
                <g fill="currentColor">
                  {/* Roof and House Structure */}
                  <path d="M50 200 L200 100 L350 200 L350 300 L50 300 Z" fill="none" stroke="currentColor" strokeWidth="15"/>
                  <rect x="150" y="220" width="100" height="80" fill="none" stroke="currentColor" strokeWidth="10"/>
                  
                  {/* Window */}
                  <rect x="170" y="230" width="60" height="60" fill="none" stroke="currentColor" strokeWidth="8"/>
                  <line x1="200" y1="230" x2="200" y2="290" stroke="currentColor" strokeWidth="8"/>
                  <line x1="170" y1="260" x2="230" y2="260" stroke="currentColor" strokeWidth="8"/>
                  
                  {/* Workers on Roof */}
                  <path d="M120 180 C120 180 150 160 180 180 C210 200 240 180 240 180" fill="none" stroke="currentColor" strokeWidth="8"/>
                  <circle cx="140" cy="170" r="15" fill="currentColor"/> {/* Worker 1 head */}
                  <path d="M130 185 L150 195 L160 185" fill="none" stroke="currentColor" strokeWidth="8"/> {/* Worker 1 body */}
                  <circle cx="220" cy="170" r="15" fill="currentColor"/> {/* Worker 2 head */}
                  <path d="M210 185 L230 195 L240 185" fill="none" stroke="currentColor" strokeWidth="8"/> {/* Worker 2 body */}
                  
                  {/* Ladder */}
                  <line x1="160" y1="200" x2="200" y2="150" stroke="currentColor" strokeWidth="8"/>
                  <line x1="180" y1="200" x2="220" y2="150" stroke="currentColor" strokeWidth="8"/>
                  <line x1="165" y1="190" x2="185" y2="190" stroke="currentColor" strokeWidth="6"/>
                  <line x1="170" y1="180" x2="190" y2="180" stroke="currentColor" strokeWidth="6"/>
                  <line x1="175" y1="170" x2="195" y2="170" stroke="currentColor" strokeWidth="6"/>
                  <line x1="180" y1="160" x2="200" y2="160" stroke="currentColor" strokeWidth="6"/>
                </g>
              </svg>
            </div>
            <div className="text-2xl font-bold text-gray-800">Toni Roofer Construct</div>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <a href="#home" className="text-gray-600 hover:text-blue-600 transition-colors">Start</a>
            <a href="#about" className="text-gray-600 hover:text-blue-600 transition-colors">Über uns</a>
            <a href="#services" className="text-gray-600 hover:text-blue-600 transition-colors">Leistungen</a>
            <a href="#gallery" className="text-gray-600 hover:text-blue-600 transition-colors">Galerie</a>
            <a href="#contact" className="text-gray-600 hover:text-blue-600 transition-colors">Kontakt</a>
          </nav>

          {/* Contact Info */}
          <div className="hidden md:flex items-center space-x-4">
            <a href="tel:015750919983" className="flex items-center text-gray-600 hover:text-blue-600">
              <Phone className="w-4 h-4 mr-2" />
              <span>015750919983</span>
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4">
            <nav className="flex flex-col space-y-4">
              <a href="#home" className="text-gray-600 hover:text-blue-600" onClick={() => setIsMenuOpen(false)}>Start</a>
              <a href="#about" className="text-gray-600 hover:text-blue-600" onClick={() => setIsMenuOpen(false)}>Über uns</a>
              <a href="#services" className="text-gray-600 hover:text-blue-600" onClick={() => setIsMenuOpen(false)}>Leistungen</a>
              <a href="#gallery" className="text-gray-600 hover:text-blue-600" onClick={() => setIsMenuOpen(false)}>Galerie</a>
              <a href="#contact" className="text-gray-600 hover:text-blue-600" onClick={() => setIsMenuOpen(false)}>Kontakt</a>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}