import React, { useState } from 'react';
import { X } from 'lucide-react';

export default function Footer() {
  const [showPrivacyPolicy, setShowPrivacyPolicy] = useState(false);

  return (
    <footer className="bg-gray-800 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-semibold mb-4">Toni Roofer Construct</h3>
            <p className="text-gray-400">
              Ihr zuverlässiger Partner für alle Dacharbeiten in Köln und Umgebung.
            </p>
          </div>
          <div>
            <h3 className="text-xl font-semibold mb-4">Kontakt</h3>
            <address className="text-gray-400 not-italic">
              Gremberger Str. 246<br />
              51151 Köln<br />
              Tel: 015750919983<br />
              E-Mail: tonigabor24@yahoo.com
            </address>
          </div>
          <div>
            <h3 className="text-xl font-semibold mb-4">Navigation</h3>
            <nav className="space-y-2">
              <a href="#home" className="block text-gray-400 hover:text-white">Start</a>
              <a href="#about" className="block text-gray-400 hover:text-white">Über uns</a>
              <a href="#services" className="block text-gray-400 hover:text-white">Leistungen</a>
              <a href="#gallery" className="block text-gray-400 hover:text-white">Galerie</a>
              <a href="#contact" className="block text-gray-400 hover:text-white">Kontakt</a>
            </nav>
          </div>
        </div>
        <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
          <p className="mb-4">&copy; {new Date().getFullYear()} Toni Roofer Construct. Alle Rechte vorbehalten.</p>
          <button
            onClick={() => setShowPrivacyPolicy(true)}
            className="text-gray-400 hover:text-white underline"
          >
            Datenschutz
          </button>
        </div>
      </div>

      {/* Privacy Policy Modal */}
      {showPrivacyPolicy && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-50">
          <div className="relative bg-white text-gray-800 rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setShowPrivacyPolicy(false)}
              className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
            >
              <X className="w-6 h-6" />
            </button>
            
            <div className="p-8">
              <h2 className="text-2xl font-bold mb-6">Datenschutzrichtlinie gemäß DSGVO</h2>
              <div className="prose max-w-none">
                <p className="mb-4">Sehr geehrte Besucher,</p>
                <p className="mb-4">
                  In Übereinstimmung mit den DSGVO-Bestimmungen informieren wir Sie, dass diese Website 
                  keine personenbezogenen Daten sammelt. Die auf dieser Website veröffentlichten 
                  Informationen dienen ausschließlich Informationszwecken.
                </p>
                <p>
                  Wenn Sie sich entscheiden, uns zu kontaktieren, verwenden wir Ihre Telefonnummer nur 
                  für den Zweck, für den Sie uns kontaktiert haben.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </footer>
  );
}