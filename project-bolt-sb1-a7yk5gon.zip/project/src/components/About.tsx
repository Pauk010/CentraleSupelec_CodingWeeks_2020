import React from 'react';

export default function About() {
  const images = [
    {
      url: "https://images.unsplash.com/photo-1632759145351-1d592919f522",
      label: "Traditionelles Schieferdach"
    },
    {
      url: "https://images.unsplash.com/photo-1600585154526-990dced4db0d",
      label: "Moderne Dachkonstruktion"
    },
    {
      url: "https://images.unsplash.com/photo-1600573472591-ee6c563aabc0",
      label: "Handwerkliche Präzision"
    }
  ];

  return (
    <section id="about" className="py-20">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 gap-12">
          {/* Image Gallery */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {images.map((image, index) => (
              <div 
                key={index}
                className="relative h-80 overflow-hidden rounded-lg shadow-lg transition-transform hover:scale-105"
              >
                <img
                  src={`${image.url}?auto=format&fit=crop&w=800&q=80`}
                  alt={image.label}
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                  <p className="text-white font-semibold">{image.label}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Content */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-start">
            <div>
              <h2 className="text-4xl font-bold text-gray-800 mb-6">Über uns</h2>
              <p className="text-lg text-gray-600 mb-6">
                Toni Roofer Construct, unter der Leitung von Toni Gabor, ist Ihr verlässlicher Partner 
                für hochwertige Dacharbeiten in Köln und Umgebung. Mit jahrelanger Erfahrung und 
                fundiertem Fachwissen garantieren wir Ihnen erstklassige Qualität bei allen Projekten.
              </p>
              <p className="text-lg text-gray-600 mb-6">
                Unsere Handwerkskunst verbindet traditionelle Techniken aus Osteuropa mit modernen 
                deutschen Standards. Diese einzigartige Kombination ermöglicht es uns, besonders 
                anspruchsvolle und ästhetisch hochwertige Dachkonstruktionen zu realisieren.
              </p>
              <p className="text-lg text-gray-600">
                Von der klassischen Dachdeckung über Flachdachsanierung bis hin zur Installation 
                moderner Dachrinnen-Systeme - wir bieten Ihnen das komplette Leistungsspektrum 
                aus einer Hand.
              </p>
            </div>

            <div className="space-y-8">
              <div className="bg-gray-50 p-6 rounded-lg shadow-md">
                <h4 className="text-xl font-semibold text-gray-800 mb-4">Unsere Werte</h4>
                <ul className="text-gray-600 space-y-3">
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3"></span>
                    Höchste Qualität
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3"></span>
                    Zuverlässigkeit
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3"></span>
                    Kundenorientierung
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3"></span>
                    Fachkompetenz
                  </li>
                </ul>
              </div>

              <div className="bg-gray-50 p-6 rounded-lg shadow-md">
                <h4 className="text-xl font-semibold text-gray-800 mb-4">Kontakt</h4>
                <address className="text-gray-600 not-italic space-y-2">
                  <p>Gremberger Str. 246</p>
                  <p>51151 Köln</p>
                  <p>Tel: <a href="tel:015750919983" className="hover:text-blue-600">015750919983</a></p>
                  <p>E-Mail: <a href="mailto:tonigabor24@yahoo.com" className="hover:text-blue-600">tonigabor24@yahoo.com</a></p>
                </address>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}