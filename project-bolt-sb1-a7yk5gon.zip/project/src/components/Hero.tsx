import React, { useState, useEffect } from 'react';
import { Phone, ChevronLeft, ChevronRight } from 'lucide-react';

const heroContent = [
  {
    type: 'image',
    url: 'https://images.unsplash.com/photo-1632759145351-1d592919f522?auto=format&fit=crop&q=80',
    title: 'Traditionelles Handwerk'
  },
  {
    type: 'image',
    url: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80',
    title: 'Moderne Dachlösungen'
  },
  {
    type: 'image',
    url: 'https://images.unsplash.com/photo-1600573472591-ee6c563aabc0?auto=format&fit=crop&q=80',
    title: 'Professionelle Ausführung'
  },
  {
    type: 'video',
    url: 'https://player.vimeo.com/external/517090081.hd.mp4?s=146b566429682d6f8173f3f68da4aa8bcc086fe2&profile_id=175',
    title: 'Unsere Arbeit in Aktion'
  }
];

export default function Hero() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);

  const nextSlide = () => {
    if (!isTransitioning) {
      setIsTransitioning(true);
      setCurrentSlide((prev) => (prev + 1) % heroContent.length);
    }
  };

  const prevSlide = () => {
    if (!isTransitioning) {
      setIsTransitioning(true);
      setCurrentSlide((prev) => (prev - 1 + heroContent.length) % heroContent.length);
    }
  };

  useEffect(() => {
    const timer = setInterval(nextSlide, 6000); // Change slide every 6 seconds
    return () => clearInterval(timer);
  }, [currentSlide]);

  const handleTransitionEnd = () => {
    setIsTransitioning(false);
  };

  return (
    <section id="home" className="relative h-screen overflow-hidden">
      {/* Background Slides */}
      {heroContent.map((content, index) => (
        <div
          key={index}
          className={`absolute inset-0 transition-opacity duration-1000 ${
            currentSlide === index ? 'opacity-100' : 'opacity-0'
          }`}
          onTransitionEnd={handleTransitionEnd}
        >
          {content.type === 'image' ? (
            <div
              className="absolute inset-0 bg-cover bg-center bg-no-repeat transform transition-transform duration-10000 scale-105"
              style={{
                backgroundImage: `url("${content.url}")`,
                animation: currentSlide === index ? 'slowZoom 10s ease-out forwards' : 'none'
              }}
            />
          ) : (
            <video
              className="absolute inset-0 w-full h-full object-cover"
              src={content.url}
              autoPlay
              muted
              loop
              playsInline
            />
          )}
          <div className="absolute inset-0 bg-navy-dark/60" />
        </div>
      ))}

      {/* Navigation Arrows */}
      <button
        onClick={prevSlide}
        className="absolute left-4 top-1/2 -translate-y-1/2 z-20 text-white/70 hover:text-white transition-colors"
        aria-label="Previous slide"
      >
        <ChevronLeft className="w-10 h-10" />
      </button>
      <button
        onClick={nextSlide}
        className="absolute right-4 top-1/2 -translate-y-1/2 z-20 text-white/70 hover:text-white transition-colors"
        aria-label="Next slide"
      >
        <ChevronRight className="w-10 h-10" />
      </button>

      {/* Slide Indicators */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-20 flex space-x-2">
        {heroContent.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
              currentSlide === index
                ? 'bg-white w-8'
                : 'bg-white/50 hover:bg-white/70'
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>

      {/* Content */}
      <div className="relative h-full flex items-center z-10">
        <div className="container mx-auto px-4 pt-20">
          <div className="max-w-3xl animate-fadeIn">
            <h1 className="text-5xl md:text-7xl font-bold text-secondary mb-6">
              Zuverlässige Dach- & Handwerksarbeiten – Für die Ewigkeit gebaut!
            </h1>
            <p className="text-xl text-white mb-8 animate-fadeIn" style={{ animationDelay: '0.2s' }}>
              Professionelle Dachlösungen und Handwerksarbeiten in Köln und Umgebung. 
              Qualität, die überzeugt – Service, der begeistert.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 animate-fadeIn" style={{ animationDelay: '0.4s' }}>
              <a
                href="#contact"
                className="inline-block bg-accent text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-accent-dark transform transition-all duration-300 hover:scale-105 hover:shadow-lg text-center"
              >
                Kostenloses Angebot
              </a>
              <a
                href="tel:015750919983"
                className="inline-flex items-center justify-center bg-secondary text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-secondary-dark transform transition-all duration-300 hover:scale-105 hover:shadow-lg gap-2"
              >
                <Phone className="w-6 h-6" />
                <span>Jetzt anrufen</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}