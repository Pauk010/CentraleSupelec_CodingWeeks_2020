/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#2563eb', // Blue
          dark: '#1d4ed8',
        },
        secondary: {
          DEFAULT: '#f97316', // Orange
          dark: '#ea580c',
        },
        accent: {
          DEFAULT: '#22c55e', // Green
          dark: '#16a34a',
        },
        navy: {
          DEFAULT: '#1e3a8a',
          light: '#2563eb',
          dark: '#172554',
        }
      },
      animation: {
        'fade-in': 'fadeIn 0.6s ease-out forwards',
        'slide-in': 'slideIn 0.5s ease-out forwards',
      },
      transitionProperty: {
        'height': 'height',
        'spacing': 'margin, padding',
      }
    },
  },
  plugins: [],
};